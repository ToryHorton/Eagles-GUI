/**
 * Coach model for football team management.
 */
public class Coach {
    private final String name;
    private final String position;
    private final String specialty;

    public Coach(String name, String position, String specialty) {
        this.name = name;
        this.position = position;
        this.specialty = specialty;
    }

    public String getName() { return name; }
    public String getPosition() { return position; }
    public String getSpecialty() { return specialty; }

    @Override
    public String toString() {
        return String.format("%s — %s (%s)", name, position, specialty);
    }
}
