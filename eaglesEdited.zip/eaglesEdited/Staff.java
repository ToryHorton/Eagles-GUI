/**
 * Staff model for football team management.
 */
public class Staff {
    private final String name;
    private final String department;
    private final String role;

    public Staff(String name, String department, String role) {
        this.name = name;
        this.department = department;
        this.role = role;
    }

    public String getName() { return name; }
    public String getDepartment() { return department; }
    public String getRole() { return role; }

    @Override
    public String toString() {
        return String.format("%s — %s (%s)", name, role, department);
    }
}
