import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Swing GUI application for the football team demo.
 * Enhanced with Philadelphia Eagles team colors and styling.
 * Uses CSV file for player data.
 */
public class MainGui {
    private final String teamName = "Philadelphia Eagles";
    private final String coachName = "Nick Sirianni";
    private final String stadiumName = "Lincoln Financial Field";
    private final String description = "Based in Philadelphia, Pennsylvania, the Philadelphia Eagles are a professional football team that plays in the National Football League's (NFL) East division of the National Football Conference (NFC). Explore the roster below!";
    
    private final java.util.List<Map<String, String>> players = new ArrayList<>();
    
    // Philadelphia Eagles Official Colors
    private static final Color MIDNIGHT_GREEN = new Color(0, 76, 84);      // Primary
    private static final Color SILVER = new Color(165, 172, 175);          // Secondary
    private static final Color BLACK = new Color(0, 0, 0);                 // Accent
    private static final Color WHITE = new Color(255, 255, 255);           // Text
    private static final Color DARK_GREEN = new Color(0, 50, 56);          // Darker shade
    private static final Color LIGHT_GREEN = new Color(0, 95, 106);        // Lighter shade
    private static final Color CHARCOAL = new Color(32, 32, 32);           // Dark background

    public MainGui() {
    }

    private void createAndShowGui() {
        JFrame frame = new JFrame(teamName + " - Roster Manager");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(CHARCOAL);
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Top: Team info with Eagles styling
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBackground(MIDNIGHT_GREEN);
        top.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 3),
            new EmptyBorder(15, 15, 15, 15)
        ));

        // Title with larger font
        JLabel title = new JLabel("🦅 " + teamName);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(WHITE);
        top.add(title, BorderLayout.NORTH);

        // Description
        JTextArea desc = new JTextArea(description);
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setEditable(false);
        desc.setBackground(MIDNIGHT_GREEN);
        desc.setForeground(WHITE);
        desc.setFont(new Font("Arial", Font.PLAIN, 13));
        desc.setBorder(new EmptyBorder(10, 0, 10, 0));
        top.add(desc, BorderLayout.CENTER);

        // Meta information panel
        JPanel meta = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
        meta.setBackground(DARK_GREEN);
        meta.setBorder(new EmptyBorder(8, 10, 8, 10));
        
        JLabel coachLabel = new JLabel("🏈 Coach: " + coachName);
        coachLabel.setForeground(WHITE);
        coachLabel.setFont(new Font("Arial", Font.BOLD, 13));
        meta.add(coachLabel);
        
        JLabel stadiumLabel = new JLabel("🏟️ Stadium: " + stadiumName);
        stadiumLabel.setForeground(WHITE);
        stadiumLabel.setFont(new Font("Arial", Font.BOLD, 13));
        meta.add(stadiumLabel);
        
        top.add(meta, BorderLayout.SOUTH);

        root.add(top, BorderLayout.NORTH);

        // Center: roster list and details
        JSplitPane split = new JSplitPane();
        split.setBackground(CHARCOAL);
        split.setDividerSize(8);

        // Left panel - Roster List
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(CHARCOAL);
        leftPanel.setBorder(new EmptyBorder(5, 0, 0, 5));
        
        // Top section with title and dropdown
        JPanel leftTopPanel = new JPanel(new BorderLayout(10, 0));
        leftTopPanel.setBackground(CHARCOAL);
        leftTopPanel.setBorder(new EmptyBorder(5, 10, 10, 10));
        
        JLabel rosterTitle = new JLabel("ROSTER");
        rosterTitle.setFont(new Font("Arial", Font.BOLD, 16));
        rosterTitle.setForeground(SILVER);
        leftTopPanel.add(rosterTitle, BorderLayout.WEST);
        
        leftPanel.add(leftTopPanel, BorderLayout.NORTH);

        DefaultListModel<Map<String, String>> playerListModel = new DefaultListModel<>();
        for (Map<String, String> p : players) {
            playerListModel.addElement(p);
        }
        
        JList<Map<String, String>> rosterList = new JList<>(playerListModel);
        rosterList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        rosterList.setBackground(DARK_GREEN);
        rosterList.setForeground(WHITE);
        rosterList.setSelectionBackground(LIGHT_GREEN);
        rosterList.setSelectionForeground(WHITE);
        rosterList.setFont(new Font("Arial", Font.PLAIN, 13));
        rosterList.setBorder(new EmptyBorder(5, 10, 5, 10));
        
        rosterList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, String> player = (Map<String, String>) value;
                    String number = player.getOrDefault("number", "");
                    String name = player.getOrDefault("name", "");
                    String position = player.getOrDefault("position", "");
                    setText("#" + number + " - " + name + " (" + position + ")");
                    setBorder(new EmptyBorder(8, 10, 8, 10));
                    if (isSelected) {
                        setBackground(LIGHT_GREEN);
                        setForeground(WHITE);
                        setFont(getFont().deriveFont(Font.BOLD));
                    } else {
                        setBackground(DARK_GREEN);
                        setForeground(WHITE);
                    }
                }
                return this;
            }
        });

        JScrollPane rosterScroll = new JScrollPane(rosterList);
        rosterScroll.setBorder(new LineBorder(MIDNIGHT_GREEN, 2));
        rosterScroll.getViewport().setBackground(DARK_GREEN);
        leftPanel.add(rosterScroll, BorderLayout.CENTER);
        
        split.setLeftComponent(leftPanel);

        // Right panel - Details (Player, Coach, or Staff)
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(CHARCOAL);
        rightPanel.setBorder(new EmptyBorder(5, 5, 0, 0));
        
        JLabel detailsTitle = new JLabel("DETAILS");
        detailsTitle.setFont(new Font("Arial", Font.BOLD, 16));
        detailsTitle.setForeground(SILVER);
        detailsTitle.setBorder(new EmptyBorder(5, 10, 10, 10));
        rightPanel.add(detailsTitle, BorderLayout.NORTH);

        JTextArea details = new JTextArea();
        details.setEditable(false);
        details.setFont(new Font("Arial", Font.PLAIN, 14));
        details.setBackground(DARK_GREEN);
        details.setForeground(WHITE);
        details.setBorder(new EmptyBorder(15, 15, 15, 15));
        details.setLineWrap(true);
        details.setWrapStyleWord(true);
        
        JScrollPane detailsScroll = new JScrollPane(details);
        detailsScroll.setBorder(new LineBorder(MIDNIGHT_GREEN, 2));
        detailsScroll.getViewport().setBackground(DARK_GREEN);
        rightPanel.add(detailsScroll, BorderLayout.CENTER);
        
        split.setRightComponent(rightPanel);
        split.setDividerLocation(425);

        root.add(split, BorderLayout.CENTER);

        // Bottom: search and stats
        JPanel bottom = new JPanel(new BorderLayout(10, 10));
        bottom.setBackground(CHARCOAL);
        bottom.setBorder(new EmptyBorder(10, 0, 0, 0));
        
        // Search panel
        JPanel searchPanel = new JPanel(new BorderLayout(10, 0));
        searchPanel.setBackground(MIDNIGHT_GREEN);
        searchPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 2),
            new EmptyBorder(10, 15, 10, 15)
        ));
        
        JLabel searchLabel = new JLabel("🔍 SEARCH ROSTER:");
        searchLabel.setForeground(WHITE);
        searchLabel.setFont(new Font("Arial", Font.BOLD, 13));
        searchPanel.add(searchLabel, BorderLayout.WEST);
        
        JTextField search = new JTextField(30);
        search.setFont(new Font("Arial", Font.PLAIN, 14));
        search.setBackground(WHITE);
        search.setForeground(BLACK);
        search.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        searchPanel.add(search, BorderLayout.CENTER);
        
        bottom.add(searchPanel, BorderLayout.NORTH);

        // Stats panel
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setBackground(DARK_GREEN);
        statsPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(MIDNIGHT_GREEN, 2),
            new EmptyBorder(10, 15, 10, 15)
        ));
        
        JLabel statsTitle = new JLabel("📊 TEAM STATISTICS");
        statsTitle.setFont(new Font("Arial", Font.BOLD, 14));
        statsTitle.setForeground(SILVER);
        statsTitle.setBorder(new EmptyBorder(0, 0, 8, 0));
        statsPanel.add(statsTitle, BorderLayout.NORTH);

        JTextArea stats = new JTextArea();
        stats.setEditable(false);
        stats.setBackground(DARK_GREEN);
        stats.setForeground(WHITE);
        stats.setFont(new Font("Arial", Font.PLAIN, 13));
        stats.setText("  • Total Players: " + players.size() + "\n");
        stats.setBorder(new EmptyBorder(5, 5, 5, 5));
        
        JScrollPane statsScroll = new JScrollPane(stats);
        statsScroll.setBorder(null);
        statsScroll.setPreferredSize(new Dimension(0, 100));
        statsScroll.getViewport().setBackground(DARK_GREEN);
        statsPanel.add(statsScroll, BorderLayout.CENTER);

        bottom.add(statsPanel, BorderLayout.CENTER);

        root.add(bottom, BorderLayout.SOUTH);

        // List selection -> details
        rosterList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                Map<String, String> selected = (Map<String, String>) rosterList.getSelectedValue();
                if (selected != null) {
                    details.setText(formatPlayerDetails(selected));
                } else {
                    details.setText("");
                }
            }
        });
        
        // Search filter
        search.getDocument().addDocumentListener(new DocumentListener() {
            private void filter() {
                String q = search.getText().trim().toLowerCase(Locale.ROOT);
                playerListModel.clear();
                for (Map<String, String> p : players) {
                    String name = p.getOrDefault("name", "").toLowerCase(Locale.ROOT);
                    String number = p.getOrDefault("number", "");
                    if (q.isEmpty() || name.contains(q) || number.equals(q)) {
                        playerListModel.addElement(p);
                    }
                }
            }

            @Override
            public void insertUpdate(DocumentEvent e) { filter(); }
            
            @Override
            public void removeUpdate(DocumentEvent e) { filter(); }
            
            @Override
            public void changedUpdate(DocumentEvent e) { filter(); }
        });

        frame.setContentPane(root);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                JOptionPane.showMessageDialog(null,
                    "Thanks for using the Philadelphia Eagles Roster Manager!\n\nGo Birds! 🦅",
                    "Goodbye - Eagles Roster Manager",
                    JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        });
        
        frame.setIconImage(createEaglesIcon());
        frame.setVisible(true);
    }

    private String formatPlayerDetails(Map<String, String> player) {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════════\n");
        sb.append("  PLAYER INFORMATION\n");
        sb.append("═══════════════════════════════════════\n\n");
        sb.append("  Number:     #").append(player.getOrDefault("number", "N/A")).append('\n');
        sb.append("  Name:       ").append(player.getOrDefault("name", "N/A")).append('\n');
        sb.append("  Position:   ").append(player.getOrDefault("position", "N/A")).append('\n');
        sb.append("  Role:       ").append(player.getOrDefault("role", "N/A")).append('\n');
        sb.append("  Type:       ").append(player.getOrDefault("type", "N/A")).append('\n');
        sb.append("\n═══════════════════════════════════════\n");
        return sb.toString();
    }
    
    private Image createEaglesIcon() {
        // Create a simple Eagles-colored icon
        int size = 64;
        Image img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = (Graphics2D) img.getGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw circle background
        g2d.setColor(MIDNIGHT_GREEN);
        g2d.fillOval(0, 0, size, size);
        
        // Draw border
        g2d.setColor(SILVER);
        g2d.setStroke(new BasicStroke(3));
        g2d.drawOval(2, 2, size - 4, size - 4);
        
        g2d.dispose();
        return img;
    }

    public static void main(String[] args) {
        // Show welcome pop-up and get user info
        JPanel userPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        userPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField nameField = new JTextField(15);
        
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField emailField = new JTextField(15);
        
        JLabel teamFanLabel = new JLabel("Favorite Team:");
        teamFanLabel.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField teamFanField = new JTextField(15);
        
        userPanel.add(nameLabel);
        userPanel.add(nameField);
        userPanel.add(emailLabel);
        userPanel.add(emailField);
        userPanel.add(teamFanLabel);
        userPanel.add(teamFanField);
        
        int result = JOptionPane.showConfirmDialog(null, userPanel,
            "Welcome to the Philadelphia Eagles Roster Manager!",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String teamFan = teamFanField.getText().trim();
            
            try {
                UserInfoCSVHandler.saveUserInfo(name, email, teamFan, "userinfo.csv");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving user info: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        SwingUtilities.invokeLater(() -> {
            MainGui gui = new MainGui();
            try {
                gui.loadPlayersFromCSV("test.csv");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error loading players: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            gui.createAndShowGui();
        });
    }

    private void loadPlayersFromCSV(String filename) throws IOException {
        java.util.List<String> lines = Files.readAllLines(Paths.get(filename));
        
        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty()) continue;
            
            String[] parts = line.split("\t");
            if (parts.length >= 5) {
                Map<String, String> player = new HashMap<>();
                player.put("name", parts[0].trim());
                player.put("role", parts[1].trim());
                player.put("position", parts[2].trim());
                player.put("number", parts[3].trim());
                player.put("type", parts[4].trim());
                
                players.add(player);
            }
        }
    }
}