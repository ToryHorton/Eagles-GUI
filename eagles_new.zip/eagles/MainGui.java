import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Swing GUI application for the football team demo.
 * Enhanced with Philadelphia Eagles team colors and styling.
 * Uses CSV file for player data.
 */
public class MainGui {
    private final String teamName = "Philadelphia Eagles";
    private final String coachName = "Nick Sirianni";
    private final String stadiumName = "Lincoln Financial Field";
    private final String description = "Based in Philadelphia, Pennsylvania, the Philadelphia Eagles are a professional football team that plays in the National Football League's (NFL) East division of the National Football Conference (NFC). Explore the roster below!";
    
    private final java.util.List<Map<String, String>> players = new ArrayList<>();
    
    // Philadelphia Eagles Official Colors
    private static final Color MIDNIGHT_GREEN = new Color(0, 76, 84);      // Primary
    private static final Color SILVER = new Color(165, 172, 175);          // Secondary
    private static final Color BLACK = new Color(0, 0, 0);                 // Accent
    private static final Color WHITE = new Color(255, 255, 255);           // Text
    private static final Color DARK_GREEN = new Color(0, 50, 56);          // Darker shade
    private static final Color LIGHT_GREEN = new Color(0, 95, 106);        // Lighter shade
    private static final Color CHARCOAL = new Color(32, 32, 32);           // Dark background

    public MainGui() {
    }

    private void createAndShowGui() {
        JFrame frame = new JFrame(teamName + " - Roster Manager");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(1000, 700);
        frame.setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(CHARCOAL);
        root.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Top: Team info with Eagles styling
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBackground(MIDNIGHT_GREEN);
        top.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 3),
            new EmptyBorder(15, 15, 15, 15)
        ));

        // Title with larger font
        JLabel title = new JLabel("🦅 " + teamName);
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(WHITE);
        top.add(title, BorderLayout.NORTH);

        // Description
        JTextArea desc = new JTextArea(description);
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setEditable(false);
        desc.setBackground(MIDNIGHT_GREEN);
        desc.setForeground(WHITE);
        desc.setFont(new Font("Arial", Font.PLAIN, 13));
        desc.setBorder(new EmptyBorder(10, 0, 10, 0));
        top.add(desc, BorderLayout.CENTER);

        // Meta information panel
        JPanel meta = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
        meta.setBackground(DARK_GREEN);
        meta.setBorder(new EmptyBorder(8, 10, 8, 10));
        
        JLabel coachLabel = new JLabel("🏈 Coach: " + coachName);
        coachLabel.setForeground(WHITE);
        coachLabel.setFont(new Font("Arial", Font.BOLD, 13));
        meta.add(coachLabel);
        
        JLabel stadiumLabel = new JLabel("🏟️ Stadium: " + stadiumName);
        stadiumLabel.setForeground(WHITE);
        stadiumLabel.setFont(new Font("Arial", Font.BOLD, 13));
        meta.add(stadiumLabel);
        
        top.add(meta, BorderLayout.SOUTH);

        root.add(top, BorderLayout.NORTH);

        // Center: roster list and details
        JSplitPane split = new JSplitPane();
        split.setBackground(CHARCOAL);
        split.setDividerSize(8);

        // Left panel - Roster List
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(CHARCOAL);
        leftPanel.setBorder(new EmptyBorder(5, 0, 0, 5));
        
        // Top section with title and dropdown
        JPanel leftTopPanel = new JPanel(new BorderLayout(10, 0));
        leftTopPanel.setBackground(CHARCOAL);
        leftTopPanel.setBorder(new EmptyBorder(5, 10, 10, 10));
        
        JLabel rosterTitle = new JLabel("ROSTER");
        rosterTitle.setFont(new Font("Arial", Font.BOLD, 16));
        rosterTitle.setForeground(SILVER);
        leftTopPanel.add(rosterTitle, BorderLayout.WEST);
        
        leftPanel.add(leftTopPanel, BorderLayout.NORTH);

        DefaultListModel<Map<String, String>> playerListModel = new DefaultListModel<>();
        for (Map<String, String> p : players) {
            playerListModel.addElement(p);
        }
        
        JList<Map<String, String>> rosterList = new JList<>(playerListModel);
        rosterList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        rosterList.setBackground(DARK_GREEN);
        rosterList.setForeground(WHITE);
        rosterList.setSelectionBackground(LIGHT_GREEN);
        rosterList.setSelectionForeground(WHITE);
        rosterList.setFont(new Font("Arial", Font.PLAIN, 13));
        rosterList.setBorder(new EmptyBorder(5, 10, 5, 10));
        
        rosterList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, String> player = (Map<String, String>) value;
                    String number = player.getOrDefault("number", "");
                    String name = player.getOrDefault("name", "");
                    String position = player.getOrDefault("position", "");
                    setText("#" + number + " - " + name + " (" + position + ")");
                    setBorder(new EmptyBorder(8, 10, 8, 10));
                    if (isSelected) {
                        setBackground(LIGHT_GREEN);
                        setForeground(WHITE);
                        setFont(getFont().deriveFont(Font.BOLD));
                    } else {
                        setBackground(DARK_GREEN);
                        setForeground(WHITE);
                    }
                }
                return this;
            }
        });

        JScrollPane rosterScroll = new JScrollPane(rosterList);
        rosterScroll.setBorder(new LineBorder(MIDNIGHT_GREEN, 2));
        rosterScroll.getViewport().setBackground(DARK_GREEN);
        leftPanel.add(rosterScroll, BorderLayout.CENTER);
        
        split.setLeftComponent(leftPanel);

        // Right panel - Details (Player, Coach, or Staff)
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(CHARCOAL);
        rightPanel.setBorder(new EmptyBorder(5, 5, 0, 0));
        
        JLabel detailsTitle = new JLabel("DETAILS");
        detailsTitle.setFont(new Font("Arial", Font.BOLD, 16));
        detailsTitle.setForeground(SILVER);
        detailsTitle.setBorder(new EmptyBorder(5, 10, 10, 10));
        rightPanel.add(detailsTitle, BorderLayout.NORTH);

        JTextArea details = new JTextArea();
        details.setEditable(false);
        details.setFont(new Font("Arial", Font.PLAIN, 14));
        details.setBackground(DARK_GREEN);
        details.setForeground(WHITE);
        details.setBorder(new EmptyBorder(15, 15, 15, 15));
        details.setLineWrap(true);
        details.setWrapStyleWord(true);
        
        JScrollPane detailsScroll = new JScrollPane(details);
        detailsScroll.setBorder(new LineBorder(MIDNIGHT_GREEN, 2));
        detailsScroll.getViewport().setBackground(DARK_GREEN);
        rightPanel.add(detailsScroll, BorderLayout.CENTER);
        
        split.setRightComponent(rightPanel);
        split.setDividerLocation(425);

        root.add(split, BorderLayout.CENTER);

        // Bottom: search and stats
        JPanel bottom = new JPanel(new BorderLayout(10, 10));
        bottom.setBackground(CHARCOAL);
        bottom.setBorder(new EmptyBorder(10, 0, 0, 0));
        
        // Search panel
        JPanel searchPanel = new JPanel(new BorderLayout(10, 0));
        searchPanel.setBackground(MIDNIGHT_GREEN);
        searchPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 2),
            new EmptyBorder(10, 15, 10, 15)
        ));
        
        JLabel searchLabel = new JLabel("🔍 SEARCH ROSTER:");
        searchLabel.setForeground(WHITE);
        searchLabel.setFont(new Font("Arial", Font.BOLD, 13));
        searchPanel.add(searchLabel, BorderLayout.WEST);
        
        JTextField search = new JTextField(30);
        search.setFont(new Font("Arial", Font.PLAIN, 14));
        search.setBackground(WHITE);
        search.setForeground(BLACK);
        search.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 1),
            new EmptyBorder(5, 10, 5, 10)
        ));
        searchPanel.add(search, BorderLayout.CENTER);
        
        bottom.add(searchPanel, BorderLayout.NORTH);

        // Filter panel with dropdowns
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        filterPanel.setBackground(MIDNIGHT_GREEN);
        filterPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(SILVER, 1),
            new EmptyBorder(5, 15, 5, 15)
        ));
        
        JLabel roleLabel = new JLabel("Filter by Role:");
        roleLabel.setForeground(WHITE);
        roleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        
        String[] roles = {"All Roles", "Player", "Coach", "Staff"};
        JComboBox<String> roleDropdown = new JComboBox<>(roles);
        roleDropdown.setBackground(DARK_GREEN);
        roleDropdown.setForeground(WHITE);
        roleDropdown.setFont(new Font("Arial", Font.PLAIN, 12));
        
        JLabel typeLabel = new JLabel("Filter by Type:");
        typeLabel.setForeground(WHITE);
        typeLabel.setFont(new Font("Arial", Font.BOLD, 12));
        
        String[] types = {"All Types", "Offense", "Defense"};
        JComboBox<String> typeDropdown = new JComboBox<>(types);
        typeDropdown.setBackground(DARK_GREEN);
        typeDropdown.setForeground(WHITE);
        typeDropdown.setFont(new Font("Arial", Font.PLAIN, 12));
        
        JLabel sortLabel = new JLabel("Sort by:");
        sortLabel.setForeground(WHITE);
        sortLabel.setFont(new Font("Arial", Font.BOLD, 12));
        
        String[] sortOptions = {"Alphabetical", "Jersey Number", "Position"};
        JComboBox<String> sortDropdown = new JComboBox<>(sortOptions);
        sortDropdown.setBackground(DARK_GREEN);
        sortDropdown.setForeground(WHITE);
        sortDropdown.setFont(new Font("Arial", Font.PLAIN, 12));
        
        filterPanel.add(roleLabel);
        filterPanel.add(roleDropdown);
        filterPanel.add(typeLabel);
        filterPanel.add(typeDropdown);
        filterPanel.add(sortLabel);
        filterPanel.add(sortDropdown);
        
        bottom.add(filterPanel, BorderLayout.CENTER);

        // Stats panel
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setBackground(DARK_GREEN);
        statsPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(MIDNIGHT_GREEN, 2),
            new EmptyBorder(10, 15, 10, 15)
        ));
        
        JLabel statsTitle = new JLabel("📊 TEAM STATISTICS");
        statsTitle.setFont(new Font("Arial", Font.BOLD, 14));
        statsTitle.setForeground(SILVER);
        statsTitle.setBorder(new EmptyBorder(0, 0, 8, 0));
        statsPanel.add(statsTitle, BorderLayout.NORTH);

        JTextArea stats = new JTextArea();
        stats.setEditable(false);
        stats.setBackground(DARK_GREEN);
        stats.setForeground(WHITE);
        stats.setFont(new Font("Arial", Font.PLAIN, 13));
        StringBuilder statsText = new StringBuilder();
        statsText.append("  • Total Players: ").append(players.size()).append("\n");
        statsText.append("  • Total Points (This Season): 379\n");
        statsText.append("  • Total Touchdowns (This Season): 45\n");
        statsText.append("  • Super Bowls Won: 2\n");
        statsText.append("  • Total Seasons: 93\n");
        statsText.append("  • Record (W/L/T): 649/645/27\n");
        stats.setText(statsText.toString());
        stats.setBorder(new EmptyBorder(5, 5, 5, 5));
        
        JScrollPane statsScroll = new JScrollPane(stats);
        statsScroll.setBorder(null);
        statsScroll.setPreferredSize(new Dimension(0, 100));
        statsScroll.getViewport().setBackground(DARK_GREEN);
        statsPanel.add(statsScroll, BorderLayout.CENTER);

        bottom.add(statsPanel, BorderLayout.SOUTH);

        root.add(bottom, BorderLayout.SOUTH);

        // List selection -> details
        rosterList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                Map<String, String> selected = (Map<String, String>) rosterList.getSelectedValue();
                if (selected != null) {
                    details.setText(formatPlayerDetails(selected));
                } else {
                    details.setText("");
                }
            }
        });
        
        // Search filter with role and type dropdowns
        Runnable updateFilter = () -> {
            String q = search.getText().trim().toLowerCase(Locale.ROOT);
            String selectedRole = (String) roleDropdown.getSelectedItem();
            String selectedType = (String) typeDropdown.getSelectedItem();
            String sortBy = (String) sortDropdown.getSelectedItem();
            
            java.util.List<Map<String, String>> filtered = new ArrayList<>();
            for (Map<String, String> p : players) {
                String name = p.getOrDefault("name", "").toLowerCase(Locale.ROOT);
                String position = p.getOrDefault("position", "").toLowerCase(Locale.ROOT);
                String number = p.getOrDefault("number", "");
                String role = p.getOrDefault("role", "");
                String type = p.getOrDefault("type", "");
                
                // Check search query
                boolean matchesSearch = q.isEmpty() || name.contains(q) || 
                                    number.equals(q) || position.contains(q);
                
                // Check role filter
                boolean matchesRole = "All Roles".equals(selectedRole) || 
                                    role.equals(selectedRole);
                
                // Check type filter
                boolean matchesType = "All Types".equals(selectedType) || 
                                    type.equals(selectedType);
                
                if (matchesSearch && matchesRole && matchesType) {
                    filtered.add(p);
                }
            }
            
            // Sort the filtered results
            switch (sortBy) {
                case "Jersey Number" -> filtered.sort((a, b) -> {
                    String numStrA = a.getOrDefault("number", "");
                    String numStrB = b.getOrDefault("number", "");
                    
                    // Check if either is N/A or empty
                    boolean isNAA = numStrA.isEmpty() || numStrA.equals("N/A") || numStrA.equals("N/a");
                    boolean isNAB = numStrB.isEmpty() || numStrB.equals("N/A") || numStrB.equals("N/a");
                    
                    // If both are N/A, maintain order
                    if (isNAA && isNAB) return 0;
                    // If A is N/A, put it at the end
                    if (isNAA) return 1;
                    // If B is N/A, put it at the end
                    if (isNAB) return -1;
                    
                    // Both have valid numbers, sort numerically
                    try {
                        int numA = Integer.parseInt(numStrA);
                        int numB = Integer.parseInt(numStrB);
                        return Integer.compare(numA, numB);
                    } catch (NumberFormatException e) {
                        return 0;
                    }
                });
                case "Position" -> filtered.sort((a, b) -> 
                    a.getOrDefault("position", "").compareTo(b.getOrDefault("position", ""))
                );
                default -> filtered.sort((a, b) -> 
                    a.getOrDefault("name", "").compareTo(b.getOrDefault("name", ""))
                );
            }
            
            playerListModel.clear();
            for (Map<String, String> p : filtered) {
                playerListModel.addElement(p);
            }
        };
        
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { updateFilter.run(); }
            
            @Override
            public void removeUpdate(DocumentEvent e) { updateFilter.run(); }
            
            @Override
            public void changedUpdate(DocumentEvent e) { updateFilter.run(); }
        });
        
        // Add listener for role dropdown
        roleDropdown.addActionListener(e -> updateFilter.run());
        
        // Add listener for type dropdown
        typeDropdown.addActionListener(e -> updateFilter.run());
        
        // Add listener for sort dropdown
        sortDropdown.addActionListener(e -> updateFilter.run());

        frame.setContentPane(root);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                JOptionPane.showMessageDialog(null,
                    "Thanks for using the Philadelphia Eagles Roster Manager!\n\nGo Birds! 🦅",
                    "Goodbye - Eagles Roster Manager",
                    JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        });
        
        frame.setIconImage(createEaglesIcon());
        frame.setVisible(true);
    }

    private String formatPlayerDetails(Map<String, String> player) {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════════\n");
        sb.append("  PLAYER INFORMATION\n");
        sb.append("═══════════════════════════════════════\n\n");
        sb.append("  Number:     #").append(player.getOrDefault("number", "N/A")).append('\n');
        sb.append("  Name:       ").append(player.getOrDefault("name", "N/A")).append('\n');
        sb.append("  Position:   ").append(player.getOrDefault("position", "N/A")).append('\n');
        sb.append("  Role:       ").append(player.getOrDefault("role", "N/A")).append('\n');
        sb.append("  Type:       ").append(player.getOrDefault("type", "N/A")).append('\n');
        sb.append("\n═══════════════════════════════════════\n");
        return sb.toString();
    }
    
    private Image createEaglesIcon() {
        // Create a simple Eagles-colored icon
        int size = 64;
        Image img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = (Graphics2D) img.getGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw circle background
        g2d.setColor(MIDNIGHT_GREEN);
        g2d.fillOval(0, 0, size, size);
        
        // Draw border
        g2d.setColor(SILVER);
        g2d.setStroke(new BasicStroke(3));
        g2d.drawOval(2, 2, size - 4, size - 4);
        
        g2d.dispose();
        return img;
    }

    public class UserInfoCSVHandler {
    
    /**
     * Save user information to a CSV file
     */
    public static void saveUserInfo(String name, String email, String favoriteTeam, String filename) throws IOException {
        boolean fileExists = Files.exists(Paths.get(filename));
        
        try (FileWriter fw = new FileWriter(filename, true);
            PrintWriter writer = new PrintWriter(fw)) {
            
            // Write header if file doesn't exist
            if (!fileExists) {
                writer.println("Name,Email,Favorite Team,Login Date/Time");
            }
            
            // Write user data with timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            String line = String.format("%s,%s,%s,%s",
                escapeCSV(name),
                escapeCSV(email),
                escapeCSV(favoriteTeam),
                timestamp
            );
            writer.println(line);
        }
    }
    
    /**
     * Escape special characters in CSV fields
     */
    private static String escapeCSV(String value) {
        if (value == null || value.isEmpty()) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}

    public static void main(String[] args) {
        // Show welcome pop-up and get user info
        JPanel userPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        userPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField nameField = new JTextField(15);
        
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField emailField = new JTextField(15);
        
        JLabel teamFanLabel = new JLabel("Favorite Team:");
        teamFanLabel.setFont(new Font("Arial", Font.BOLD, 12));
        JTextField teamFanField = new JTextField(15);
        
        userPanel.add(nameLabel);
        userPanel.add(nameField);
        userPanel.add(emailLabel);
        userPanel.add(emailField);
        userPanel.add(teamFanLabel);
        userPanel.add(teamFanField);
        
        int result = JOptionPane.showConfirmDialog(null, userPanel,
            "Welcome to the Philadelphia Eagles Roster Manager!",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String teamFan = teamFanField.getText().trim();
            
            try {
                UserInfoCSVHandler.saveUserInfo(name, email, teamFan, "userinfo.csv");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving user info: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        SwingUtilities.invokeLater(() -> {
            MainGui gui = new MainGui();
            try {
                gui.loadPlayersFromCSV("team.csv");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error loading players: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            gui.createAndShowGui();
        });
    }

    private void loadPlayersFromCSV(String filename) throws IOException {
        java.nio.file.Path filePath = Paths.get(filename);
        
        // Check if file exists, if not create it with default data
        if (!Files.exists(filePath)) {
            createDefaultCSV(filename);
        }
        
        java.util.List<String> lines = Files.readAllLines(filePath);
        
        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty()) continue;
            
            String[] parts = line.split(",");
            if (parts.length >= 5) {
                Map<String, String> player = new HashMap<>();
                player.put("name", parts[0].trim());
                player.put("role", parts[1].trim());
                player.put("position", parts[2].trim());
                player.put("number", parts[3].trim());
                player.put("type", parts[4].trim());
                
                players.add(player);
            }
        }
    }
    
    private void createDefaultCSV(String filename) throws IOException {
        try (FileWriter fw = new FileWriter(filename);
            PrintWriter writer = new PrintWriter(fw)) {
            // Write header
            writer.println("Name,Role,Position,Number,Type");
            // Write player data
            writer.println("Sam Howell,Player,Quarterback,14,Offense");
            writer.println("Jalen Hurts,Player,Quarterback,1,Offense");
            writer.println("Tanner McKee,Player,Quarterback,16,Offense");
            writer.println("Saquon Barkley,Player,Runningback,26,Offense");
            writer.println("Tank Bigsby,Player,Runningback,37,Offense");
            writer.println("AJ Dillon,Player,Runningback,29,Offense");
            writer.println("Will Shipley,Player,Runningback,28,Offense");
            writer.println("Carson Steele,Player,Runningback,42,Offense");
            writer.println("A.J. Brown,Player,Wide Receiver,11,Offense");
            writer.println("Darius Cooper,Player,Wide Receiver,80,Offense");
            writer.println("Britain Covey,Player,Wide Receiver,18,Offense");
            writer.println("Jahan Dotson,Player,Wide Receiver,2,Offense");
            writer.println("Danny Gray,Player,Wide Receiver,46,Offense");
            writer.println("DeVonta Smith,Player,Wide Receiver,6,Offense");
            writer.println("Quez Watkins,Player,Wide Receiver,16,Offense");
            writer.println("Grant Calcaterra,Player,Tight End,81,Offense");
            writer.println("Dallas Goedert,Player,Tight End,88,Offense");
            writer.println("Kylen Granson,Player,Tight End,83,Offense");
            writer.println("E.J. Jenkins,Player,Tight End,84,Offense");
            writer.println("Cameron Latu,Player,Tight End,36,Offense");
            writer.println("Cam Jurgens,Player,Center,51,Offense");
            writer.println("Drew Kendall,Player,Center,66,Offense");
            writer.println("Jake Majors,Player,Center,75,Offense");
            writer.println("Brett Toth,Player,Center,64,Offense");
            writer.println("Landon Dickerson,Player,Guard,69,Offense");
            writer.println("Tyler Steen,Player,Guard,56,Offense");
            writer.println("Fred Johnson,Player,Offensive Tackle,74,Offense");
            writer.println("Lane Johnson,Player,Offensive Tackle,65,Offense");
            writer.println("Jordan Mailata,Player,Offensive Tackle,68,Offense");
            writer.println("John Ojukwu,Player,Offensive Tackle,61,Offense");
            writer.println("Hollin Pierce,Player,Offensive Tackle,63,Offense");
            writer.println("Matt Pryor,Player,Offensive Tackle,79,Offense");
            writer.println("Cameron Williams,Player,Offensive Tackle,73,Offense");
            writer.println("Brandon Graham,Player,Defensive End,55,Defense");
            writer.println("Jose Ramirez,Player,Defensive End,N/A,Defense");
            writer.println("Jalen Carter,Player,Defensive Tackle,98,Defense");
            writer.println("Jordan Davis,Player,Defensive Tackle,90,Defense");
            writer.println("Gabe Hall,Player,Defensive Tackle,96,Defense");
            writer.println("Moro Ojomo,Player,Defensive Tackle,97,Defense");
            writer.println("Ty Robinson,Player,Defensive Tackle,95,Defense");
            writer.println("Jacob Sykes,Player,Defensive Tackle,93,Defense");
            writer.println("Byron Young,Player,Defensive Tackle,94,Defense");
            writer.println("Zack Baun,Player,Linebacker,53,Defense");
            writer.println("Chance Campbell,Player,Linebacker,59,Defense");
            writer.println("Jihaad Campbell,Player,Linebacker,30,Defense");
            writer.println("Nakobe Dean,Player,Linebacker,17,Defense");
            writer.println("Jalyx Hunt,Player,Linebacker,58,Defense");
            writer.println("Smael Mondon Jr,Player,Linebacker,42,Defense");
            writer.println("Jaelan Phillips,Player,Linebacker,50,Defense");
            writer.println("Nolan Smith Jr,Player,Linebacker,3,Defense");
            writer.println("Jeremiah Trotter Jr,Player,Linebacker,54,Defense");
            writer.println("Joshua Uche,Player,Linebacker,0,Defense");
            writer.println("Jakorian Bennett,Player,Cornerback,23,Defense");
            writer.println("Michael Carter II,Player,Cornerback,35,Defense");
            writer.println("Tariq Castro-Fields,Player,Cornerback,46,Defense");
            writer.println("Cooper DeJean,Player,Cornerback,33,Defense");
            writer.println("Adoree' Jackson,Player,Cornerback,8,Defense");
            writer.println("Brandon Johnson,Player,Cornerback,49,Defense");
            writer.println("Mac McWilliams,Player,Cornerback,22,Defense");
            writer.println("Quinyon Mitchell,Player,Cornerback,27,Defense");
            writer.println("Kelee Ringo,Player,Cornerback,7,Defense");
            writer.println("Ambry Thomas,Player,Defensive Back,38,Defense");
            writer.println("Reed Blankenship,Player,Safety,32,Defense");
            writer.println("Sydney Brown,Player,Safety,21,Defense");
            writer.println("Marcus Epps,Player,Safety,39,Defense");
            writer.println("Andre' Sam,Player,Safety,31,Defense");
            // Write coaching staff
            writer.println("Nick Sirianni,Coach,Head Coach,N/A,N/A");
            writer.println("Michael Clay,Coach,Special Teams Coordinator,N/A,N/A");
            writer.println("Vic Fangio,Coach,Defensive Coordinator,N/A,Defense");
            writer.println("Kevin Patullo,Coach,Offensive Coordinator,N/A,Offense");
            writer.println("Roy Anderson,Coach,Cornerbacks Coach,N/A,Defense");
            writer.println("Joe Kasper,Coach,Safeties Coach,N/A,Defense");
            writer.println("Bobby King,Coach,Inside Linebackers Coach,N/A,Defense");
            writer.println("Scot Loeffler,Coach,Quarterbacks Coach,N/A,Offense");
            writer.println("Jason Michael,Coach,Tight Ends Coach,N/A,Offense");
            writer.println("Aaron Moorehead,Coach,Wide Receivers Coach,N/A,Offense");
            // Write staff
            writer.println("Mark Konsewicz,Staff,Head Athletic Trainer,N/A,N/A");
            writer.println("Chris Peduzzi,Staff,Assistant Athletic Trainer,N/A,N/A");
            writer.println("Jonathan Gormley,Staff,Assistant Athletic Trainer,N/A,N/A");
            writer.println("Clyde McGrady,Staff,Strength & Conditioning Coach,N/A,N/A");
            writer.println("David Morris,Staff,Assistant Strength Coach,N/A,N/A");
            writer.println("Dr. Stewart Tepper,Staff,Team Physician,N/A,N/A");
            writer.println("Dr. Ashish Joshi,Staff,Team Orthopedic Surgeon,N/A,N/A");
            writer.println("Chris Rees,Staff,Equipment Manager,N/A,N/A");
            writer.println("Marcus Mariota,Staff,Offensive Consultant,N/A,Offense");
            writer.println("Brandon Graham,Staff,Scout,N/A,N/A");
            writer.println("Tom Donahoe,Staff,Senior Personnel Advisor,N/A,N/A");
            writer.println("Ray Didinger,Staff,Media Relations,N/A,N/A");
        }
    }
}